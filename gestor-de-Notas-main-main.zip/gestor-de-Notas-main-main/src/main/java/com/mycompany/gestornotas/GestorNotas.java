/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.gestornotas;

import com.mycompany.gestornotas.vistas.VSeleccion;

/**
 *
 * @author Admin
 */
public class GestorNotas {

    public static void main(String[] args) {
        //visualizar la vista 
        VSeleccion vista = new VSeleccion();
        vista.setVisible(true);
    }
}
